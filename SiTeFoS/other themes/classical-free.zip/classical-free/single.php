<?php get_header(); ?>

	<?php if (have_posts()) : while(have_posts()) : the_post(); ?>
    <div class="content-wrap">
    <section class="posts">
        <div class="container">
           <div class="row">
            	<?php 
            		$args = array(
            			'post_type' 	=> 'attachment',
            			'numberposts'	=> -1,
            			'post_status'	=> 'any',
            			'post_parent'	=> $post->ID
            		);
            		$attachments = get_posts($args);

            	$btn_like = '<li class="post-like">'.getPostLikeLink(get_the_ID()).'</li>';
              $btn_share = '
              <li class="dropup">
                <span class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                     <i class="fa fa-share-alt"></i>
                 </span>
                <ul class="dropdown-menu" role="menu">
                    <li>
                      <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u='.wp_get_shortlink().'">
                        <i class="fa fa-facebook"></i>
                      </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                      <a target="_blank" href="https://twitter.com/intent/tweet?text='.get_the_title().'&url='.wp_get_shortlink().'">
                        <i class="fa fa-twitter"></i>
                      </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                      <a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url='.wp_get_shortlink().'">
                        <i class="fa fa-linkedin"></i>
                      </a>
                    </li>
                </ul>
              </li>';
              $post_date_option = '<span class="post-date">'.get_the_date().'</span>';

   if (has_post_thumbnail(get_the_ID())) {
    ?>
               <!-- Start post/text-img-post -->
               <article class="post text-img-post single-post">
                   <header class="post-header">
                        <?php the_post_thumbnail( array(760, 355) ); ?>
                   </header><!-- End post-header -->
                   <div class="post-content">
                        <h1><?php the_title(); ?></h1>
                        <?php the_content(); ?>
                   </div><!-- End post-content -->
                   <footer class="post-footer">
                       <?php echo $post_date_option; ?>
                       <ul class="post-share">
                            <?php echo $btn_like; ?>
                           <?php echo $btn_share; ?>
                       </ul><!-- End post-share -->
                   </footer><!-- End post-footer -->
               </article><!-- End post/text-img-post -->
    <?php
    } else {
    ?>
               <!-- Start post/text-post -->
               <article class="post text-post single-post">
                   <header class="post-header">
                        <h1><?php the_title(); ?></h1>
                   </header><!-- End post-header -->
                   <div class="post-content">
                        <?php the_content(); ?>
                   </div><!-- End post-content -->
                   <footer class="post-footer">
                       <?php echo $post_date_option; ?>
                       <ul class="post-share">
                            <?php echo $btn_like; ?>
                           <?php echo $btn_share; ?>
                       </ul><!-- End post-share -->
                   </footer><!-- End post-footer -->
               </article><!-- End post/text-post -->
        <?php
            }
        ?>

			<?php 
			if(wp_get_post_tags(get_the_ID())){
				$tags = wp_get_post_tags(get_the_ID());
		?>
          <!-- Start post-tags -->
          <div class="post-tags">
             <div class="container">
                 <div class="row">
                      <strong>الوسوم:</strong>
                      <div>
          <?php
            foreach ($tags as $tag) {
              echo '<a href="'.get_tag_link($tag->term_id).'" rel="tag">'.$tag->name.'</a>';
            }
          ?>
                      </div>
                 </div><!-- End row -->
             </div><!-- End container -->
          </div><!-- End post-tags -->
          <?php 
        } 
        
            	endwhile;
                endif;
            ?>
            <?php comments_template(); ?>
           </div><!-- End row -->
        </div><!-- End container -->
    </section><!-- End posts -->

<?php get_footer(); ?>