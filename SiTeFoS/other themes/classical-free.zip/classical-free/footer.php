    <footer class="footer align-center">
       <div class="container footer">
           <div class="row">
                <p>
                    كافة الحقوق محفوظة © - <?php bloginfo('name'); echo ' '.date('Y');?> 
                </p>
           </div><!-- End row -->
       </div><!-- End container -->
    </footer><!-- End footer -->
</div><!-- End content-wrap -->
</div><!-- End content-all-->
  <script src="<?php echo THEMROOT.'/'; ?>js/jquery-2.1.3.min.js"></script>
	<script src="<?php echo THEMROOT.'/'; ?>js/bootstrap.min.js"></script>
	<script src="<?php echo THEMROOT.'/'; ?>js/jquery.fancybox.pack.js"></script>
	<script src="<?php echo THEMROOT.'/'; ?>js/jquery.sidr.min.js"></script>
	<script src="<?php echo THEMROOT.'/'; ?>js/custom.js"></script>
  <?php wp_footer(); ?>
</body>
</html>