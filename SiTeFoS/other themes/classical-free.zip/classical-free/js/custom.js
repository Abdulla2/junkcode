$(document).ready(function() {
    
    $(window).scroll(function () {
        if ($(this).scrollTop() > 225) {
            $(".top-bar").addClass("scroll-top-bar").fadeIn();
        } else {
            $(".top-bar").removeClass("scroll-top-bar");
            
        }
    });

    
    // Show Search Form
    
    $('.search-icon').click(function(){
        
        search_mode = $('.search-cont').attr('data');
        if (search_mode == "hide") {
            $(".search-cont").css({
                'opacity'    : "1", 
                'visibility' : "visible"
            });
            
            $("body").css({
                'overflow'    : "hidden"
            });
            
            $(document).keyup(function(e) {
              if (e.keyCode == 27) {
                  
                  $('.search-cont').css({
                     'opacity'    : "0", 
                     'visibility' : "hidden"
                  });  // esc
                  
                  $("body").css({
                    'overflow'    : "auto"
                  });
                  
                  $('.search-cont').attr('data', 'hide');
                  $(".search-icon").removeClass("fa-times");
                  $(".search-icon").addClass("fa-search");
              }
            });
            
            $('.search-cont').attr('data', 'show');
            $(".search-icon").removeClass("fa-search");
            $(".search-icon").addClass("fa-times");
            
        } else {
            
            $(".search-cont").css({
                'opacity'    : "0", 
                'visibility' : "hidden"
            });
            
            $("body").css({
                'overflow'    : "auto"
            });
            
            $('.search-cont').attr('data', 'hide');
            $(".search-icon").removeClass("fa-times");
            $(".search-icon").addClass("fa-search");
        }
        return false;
    });
    
    
    // Show Comments Form
    // how to keep scroll position jquery
    $('.btn-comment').click(function(){
        comments_mode = $('.add-comments').attr('data-comments');
        if (comments_mode == "hide") {
            $(".add-comments").css({
                'opacity'    : "1", 
                'visibility' : "visible"
            });
            
            $("body").css({
                'overflow'    : "hidden"
            });
            
            $(document).keyup(function(e) {
              if (e.keyCode == 27) {
                  
                  $('.add-comments').css({
                     'opacity'    : "0", 
                     'visibility' : "hidden"
                  });  // esc
                  
                  $("body").css({
                      'overflow'    : "auto"
                  });
                  
                  $('.add-comments').attr('data-comments', 'hide');
              }
            });
            
            $('.add-comments').attr('data-comments', 'show');
            
        } else {
            
            $(".add-comments").css({
                'opacity'    : "0", 
                'visibility' : "hidden"
            });
            
            $("body").css({
                'overflow'    : "auto"
            });
            
            $('.add-comments').attr('data-comments', 'hide');
        }
        return false;
    });
    

    $('.simple-menu').sidr({
        side    : 'right',
        onOpen  : function(){
            $(".content-all").addClass("sidebar-open");
            $("html").css({'overflow': "hidden"});
            $(".top-bar").animate({right : '260px'}, 200);
        },
        onClose : function(){
            $(".content-all").removeClass("sidebar-open");
            $(".top-bar").animate({right : '0'}, 200);
        }
    });
    
    $('.content-all').click(function(){
        $.sidr('close');
    });
    
    $('.fancybox').fancybox({
        padding : 0,
        helpers:  {
            overlay : {
                css : {
                    'background' : 'rgba(11,11,11,0.8)'
                }
            }
        }
    });
    
    $('.hide-search').click(function(){
        $('.search-cont').css({
            'opacity'    : "0", 
            'visibility' : "hidden"
        });

        $("body").css({
            'overflow'    : "auto"
        });

        $('.search-cont').attr('data', 'hide');
        $(".search-icon").removeClass("fa-times");
        $(".search-icon").addClass("fa-search");
        
    });
    
    $('.hide-comments').click(function(){
        $('.add-comments').css({
            'opacity'    : "0", 
            'visibility' : "hidden"
        });

        $("body").css({
            'overflow'    : "auto"
        });

        $('.add-comments').attr('data-comments', 'hide');
        
    });

    // 


    if (window.location.href.indexOf("#comments") > -1 || window.location.href.indexOf("#respond") > -1) {
        $(".add-comments").css({
            'opacity'    : "1", 
            'visibility' : "visible"
        });
        
        $("body").css({
            'overflow'    : "hidden"
        });

        $('.add-comments').attr('data-comments', 'show');
    }

    $('.search-open').click(function(){
        $(".search-cont").css({
            'opacity'    : "1", 
            'visibility' : "visible"
        });
        
        $("body").css({
            'overflow'    : "hidden"
        });

        $('.search-cont').attr('data', 'show');
    });

});

