<div class="search-cont" data="hide">
   <div class="container">
       <div class="row">
            <div class="input-group">
               <span>هل تبحث عن شيئ معين في المدونة ؟ اكتب الجملة أو الكلمة التي تريد البحث عنها، واضغط Enter</span>
                <form class="search-form" action="<?php echo home_url(); ?>" accept-charset="utf-8" method="get">
                   <input type="text" class="form-control" name="s" id="s" placeholder="بحث...">
                </form>
            </div>
       </div>
    </div>
    <div class="hide-search"></div>
</div>