<?php 
if (!empty($_SERVER['SCRIPT-FILENAME']) && basename($_SERVER['SCRIPT-FILENAME'] == 'comments.php')) {
    die('غير مصرح لك بالدخول الى هذا الملف.');
}
// Check if post is pwd protected
if (post_password_required()) { ?>
    <div class='comments-messages align-center'><h4>هذا المحتوى محمي بكلمة مرور, ادخل كلمة المرور لمشاهدة التعليقات.</h4></div>
<?php
} elseif (have_comments()) { ?>
    <div class="comments-count"><?php comments_number('', 'تعليق واحد', '% تعليقات'); ?></div>
    <section class="post-comments" id="respond">
        <ol class="comments">
            <?php wp_list_comments('callback=display_comments'); ?>
        </ol>
    </section><!-- End post-comments -->
    
    <?php

    if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
        <!-- Start pagination-page -->
        <div class="pagination-page align-center">
           <div class="container">
               <div class="row">
                    <span rel="next">
                    <?php 
                        next_comments_link('<span>التعليقات الحديثة</span><i class="fa fa-long-arrow-left"></i>');
                    ?>
                    </span>
                    <span rel="prev">
                    <?php
                        previous_comments_link('<i class="fa fa-long-arrow-right"></i><span>التعليقات القديمة</span>'); 
                    ?>
                    </span>
               </div><!-- End row -->
           </div><!-- End container -->
        </div><!-- End pagination-page -->
    <?php
    endif;

} elseif (!comments_open() && !is_page() && post_type_supports(get_post_type(), 'comments')) { ?>
    <div class='comments-messages align-center'><h4>التعليقات مغلقة لهذا المقال.</h4></div>
    
<?php
}

// Display Comment Form

if (comments_open() && !is_page() && post_type_supports(get_post_type(), 'comments')) : ?>
    <p class="comment_number">
        <?php comments_number('<div class=\'comments-messages align-center\'><h4>لا يوجد تعليقات على هذه المقالة</h4></div>', '', ''); ?>
    </p>
    <section class="add-comments" data-comments="hide">
        <div class="form-group">
           <span>اضف تعليق</span>
            <?php comment_form(); ?>
            <input class="btn btn-primary btn-comment close-comments" type="submit" value="الغاء">
        </div>
        <div class="hide-comments"></div>
    </section><!-- End add-comments -->
    <a class="btn btn-primary btn-comment">اضف تعليق</a>

<?php endif; ?>