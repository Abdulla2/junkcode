<?php get_header(); ?>

<div class="content-wrap">
    <section class="posts">
        <div class="container">
           <div class="row">
	            <div class='align-center'>
	                <h3>الصفحة المطلوبة غير موجودة</h3>
	                <p>للأسف لم يتم العثور على الصفحة التي طلبتها. قد يكون الرابط خاطئ أو الصفحة حذفت.</p>
	                <a class="search-open">إبحث</a> أو <a href="<?php echo home_url(); ?>">الرئيسية</a>
	            </div>
           </div><!-- End row -->
        </div><!-- End container -->
    </section><!-- End posts -->
    

<?php get_footer(); ?>