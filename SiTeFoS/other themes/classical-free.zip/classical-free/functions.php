<?php
/**********************************************************/
/* Define Constants */
/**********************************************************/

define('THEMROOT', get_template_directory_uri());
define('IMG', THEMROOT.'/img');

/**********************************************************/
/* Register Menus */
/**********************************************************/

function register_site_menus() {
    register_nav_menus(array(
        'sidebar-menu' => 'القائمة الجانبية'
    ));
}

add_action('init', 'register_site_menus');


/**********************************************************/
/* Register Widgets */
/**********************************************************/


function register_site_widgets() {

    register_sidebar(array(
        'name'          => 'القائمة الجانبية',
        'id'            => 'sidebar_menu',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div><div class="clearfix"></div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>'
    ));

}

add_action('widgets_init', 'register_site_widgets');
/**********************************************************/
/* Add Theme Support for Post Thumbnails */
/**********************************************************/

if (function_exists('add_theme_support')) {
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(650, 433);
}

/**********************************************************/
/* Function To Display Comments */
/**********************************************************/

function display_comments($comment, $args, $depth) {
	$_GLOBALS['comment'] = $comment;
	if (get_comment_type() == 'pingback' || get_comment_type() == 'tracback') : ?>

	<li <?php comment_class('pingback'); ?> id="comment-<?php comment_ID(); ?>">
        <span class="user-img">
        	<?php 
                if ( (get_option('admin_email') == $comment->comment_author_email) && (classic_options('custom_logo', false, 'thumbnail')) ) {
                    $user_img= '<img src="'.classic_options('custom_logo', false, 'thumbnail').'">';
                } else {
                    $user_img = get_avatar($comment, 30);
                }
                echo $user_img; 
            ?>
        </span>
        <span class="user-name"><?php echo 'Pingback:'; ?></span>
        <?php comment_author_link(); ?>
    </li>

	<?php elseif (get_comment_type() == 'comment') : ?>

	<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
        <span class="user-img">
        	<?php 
                if ( (get_option('admin_email') == $comment->comment_author_email) && (classic_options('custom_logo', false, 'thumbnail')) ) {
                    $user_img= '<img src="'.classic_options('custom_logo', false, 'thumbnail').'">';
                } else {
                    $user_img = get_avatar($comment, 30);
                }
                echo $user_img; 
            ?>
        </span>
        <span class="user-name"><?php comment_author_link(); ?></span><span class="comment-date"><?php comment_date(); ?></span>
        <span class="reply-comment">
        	<?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
        </span>
        <?php if ($comment->comment_approved == '0') : ?>
        	<span class="awaiting-moderation">تعليقك ينتظر الموافقة.</span>
        <?php endif; 
        	comment_text();
        ?>
    </li>

	<?php
	endif;
}

/**********************************************************/
/* Custom Comments Form */
/**********************************************************/

function custom_comment_form ($defaults) {
	// Display Note before form
	$defaults['comment_notes_before'] = '';
	// Display Note after form
	$defaults['comment_notes_after'] = '';
	// Add 'ID' for form
	$defaults['id_form'] = '';

	$defaults['title_reply'] = '';

	$defaults['class_submit'] = 'btn btn-primary';

	$defaults['label_submit'] = 'أضف تعليق';
	// textarea
	$defaults['comment_field'] = '<textarea name="comment" id="comment" class="form-control" placeholder="التعليق"></textarea>';

	return $defaults;
}

add_filter('comment_form_defaults', 'custom_comment_form');

function custom_comment_fields() {
	$commenter 		 = wp_get_current_commenter();
	$required_fields = get_option('required_neme_email');
	$aria_required 	 = ($required_fields ? 'aria-required="true"' : '');

	$fields = array(
		'author' => '<input type="text" class="form-control" id="author" name="author" value"'.esc_attr($commenter['comment_author']).'" placeholder="الاسم"  '.$aria_required.'>',
		'email' => '<input type="email" class="form-control" id="email" name="email" value"'.esc_attr($commenter['comment_author_email']).'" placeholder="البريد الاكتروني" '.$aria_required.' >',
	);

	return $fields;
}

add_filter('comment_form_default_fields', 'custom_comment_fields');

/**********************************************************/
/* Like Btn */
/**********************************************************/

function like_scripts() {
    wp_enqueue_script( 'jm_like_post', get_template_directory_uri().'/js/post-like.min.js', array('jquery'), '1.0', 1 );
    wp_localize_script( 'jm_like_post', 'ajax_var', array(
        'url' => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'ajax-nonce' )
        )
    );
}
add_action( 'init', 'like_scripts' );

/**
 * (2) Save like data
 */
add_action( 'wp_ajax_nopriv_jm-post-like', 'jm_post_like' );
add_action( 'wp_ajax_jm-post-like', 'jm_post_like' );
function jm_post_like() {
    $nonce = $_POST['nonce'];
    if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) )
        die ( 'Nope!' );
    
    if ( isset( $_POST['jm_post_like'] ) ) {
    
        $post_id = $_POST['post_id']; // post id
        $post_like_count = get_post_meta( $post_id, "_post_like_count", true ); // post like count
        
        if ( function_exists ( 'wp_cache_post_change' ) ) { // invalidate WP Super Cache if exists
            $GLOBALS["super_cache_enabled"]=1;
            wp_cache_post_change( $post_id );
        }
        
        if ( is_user_logged_in() ) { // user is logged in
            $user_id = get_current_user_id(); // current user
            $meta_POSTS = get_user_option( "_liked_posts", $user_id  ); // post ids from user meta
            $meta_USERS = get_post_meta( $post_id, "_user_liked" ); // user ids from post meta
            $liked_POSTS = NULL; // setup array variable
            $liked_USERS = NULL; // setup array variable
            
            if ( count( $meta_POSTS ) != 0 ) { // meta exists, set up values
                $liked_POSTS = $meta_POSTS;
            }
            
            if ( !is_array( $liked_POSTS ) ) // make array just in case
                $liked_POSTS = array();
                
            if ( count( $meta_USERS ) != 0 ) { // meta exists, set up values
                $liked_USERS = $meta_USERS[0];
            }       

            if ( !is_array( $liked_USERS ) ) // make array just in case
                $liked_USERS = array();
                
            $liked_POSTS['post-'.$post_id] = $post_id; // Add post id to user meta array
            $liked_USERS['user-'.$user_id] = $user_id; // add user id to post meta array
            $user_likes = count( $liked_POSTS ); // count user likes
    
            if ( !AlreadyLiked( $post_id ) ) { // like the post
                update_post_meta( $post_id, "_user_liked", $liked_USERS ); // Add user ID to post meta
                update_post_meta( $post_id, "_post_like_count", ++$post_like_count ); // +1 count post meta
                update_user_option( $user_id, "_liked_posts", $liked_POSTS ); // Add post ID to user meta
                update_user_option( $user_id, "_user_like_count", $user_likes ); // +1 count user meta
                echo $post_like_count; // update count on front end

            } else { // unlike the post
                $pid_key = array_search( $post_id, $liked_POSTS ); // find the key
                $uid_key = array_search( $user_id, $liked_USERS ); // find the key
                unset( $liked_POSTS[$pid_key] ); // remove from array
                unset( $liked_USERS[$uid_key] ); // remove from array
                $user_likes = count( $liked_POSTS ); // recount user likes
                update_post_meta( $post_id, "_user_liked", $liked_USERS ); // Remove user ID from post meta
                update_post_meta($post_id, "_post_like_count", --$post_like_count ); // -1 count post meta
                update_user_option( $user_id, "_liked_posts", $liked_POSTS ); // Remove post ID from user meta          
                update_user_option( $user_id, "_user_like_count", $user_likes ); // -1 count user meta
                echo "already".$post_like_count; // update count on front end
                
            }
            
        } else { // user is not logged in (anonymous)
            $ip = $_SERVER['REMOTE_ADDR']; // user IP address
            $meta_IPS = get_post_meta( $post_id, "_user_IP" ); // stored IP addresses
            $liked_IPS = NULL; // set up array variable
            
            if ( count( $meta_IPS ) != 0 ) { // meta exists, set up values
                $liked_IPS = $meta_IPS[0];
            }
    
            if ( !is_array( $liked_IPS ) ) // make array just in case
                $liked_IPS = array();
                
            if ( !in_array( $ip, $liked_IPS ) ) // if IP not in array
                $liked_IPS['ip-'.$ip] = $ip; // add IP to array
            
            if ( !AlreadyLiked( $post_id ) ) { // like the post
                update_post_meta( $post_id, "_user_IP", $liked_IPS ); // Add user IP to post meta
                update_post_meta( $post_id, "_post_like_count", ++$post_like_count ); // +1 count post meta
                echo $post_like_count; // update count on front end
                
            } else { // unlike the post
                $ip_key = array_search( $ip, $liked_IPS ); // find the key
                unset( $liked_IPS[$ip_key] ); // remove from array
                update_post_meta( $post_id, "_user_IP", $liked_IPS ); // Remove user IP from post meta
                update_post_meta( $post_id, "_post_like_count", --$post_like_count ); // -1 count post meta
                echo "already".$post_like_count; // update count on front end
                
            }
        }
    }
    
    exit;
}

/**
 * (3) Test if user already liked post
 */
function AlreadyLiked( $post_id ) { // test if user liked before
    if ( is_user_logged_in() ) { // user is logged in
        $user_id = get_current_user_id(); // current user
        $meta_USERS = get_post_meta( $post_id, "_user_liked" ); // user ids from post meta
        $liked_USERS = ""; // set up array variable
        
        if ( count( $meta_USERS ) != 0 ) { // meta exists, set up values
            $liked_USERS = $meta_USERS[0];
        }
        
        if( !is_array( $liked_USERS ) ) // make array just in case
            $liked_USERS = array();
            
        if ( in_array( $user_id, $liked_USERS ) ) { // True if User ID in array
            return true;
        }
        return false;
        
    } else { // user is anonymous, use IP address for voting
    
        $meta_IPS = get_post_meta( $post_id, "_user_IP" ); // get previously voted IP address
        $ip = $_SERVER["REMOTE_ADDR"]; // Retrieve current user IP
        $liked_IPS = ""; // set up array variable
        
        if ( count( $meta_IPS ) != 0 ) { // meta exists, set up values
            $liked_IPS = $meta_IPS[0];
        }
        
        if ( !is_array( $liked_IPS ) ) // make array just in case
            $liked_IPS = array();
        
        if ( in_array( $ip, $liked_IPS ) ) { // True is IP in array
            return true;
        }
        return false;
    }
    
}

/**
 * (4) Front end button
 */
function getPostLikeLink( $post_id ) {
    $like_count = get_post_meta( $post_id, "_post_like_count", true ); // get post likes
    $count = ( empty( $like_count ) || $like_count == "0" ) ? '' : esc_attr( $like_count );
    if ( AlreadyLiked( $post_id ) ) {
        $class = esc_attr( '' );
        $title = esc_attr( '' );
        $heart = '<i id="icon-like" class="fa fa-heart actice"></i>';
    } else {
        $class = esc_attr( '' );
        $title = esc_attr( '' );
        $heart = '<i id="icon-unlike" class="fa fa-heart"></i>';
    }
    $output = '<a href="#" class="jm-post-like'.$class.'" data-post_id="'.$post_id.'" title="'.$title.'">
        '.$count.'<span>'.$heart.'</span></a>';
    return $output;
}

/**
 * (5) Retrieve User Likes and Show on Profile
 */
add_action( 'show_user_profile', 'show_user_likes' );
add_action( 'edit_user_profile', 'show_user_likes' );
function show_user_likes( $user ) { ?>        
    <table class="form-table">
        <tr>
            <th><label for="user_likes"><?php _e( 'لقد اعجبت بـ :' ); ?></label></th>
            <td>
            <?php
            $user_likes = get_user_option( "_liked_posts", $user->ID );
            if ( !empty( $user_likes ) && count( $user_likes ) > 0 ) {
                $the_likes = $user_likes;
            } else {
                $the_likes = '';
            }
            if ( !is_array( $the_likes ) )
            $the_likes = array();
            $count = count( $the_likes ); 
            $i=0;
            if ( $count > 0 ) {
                $like_list = '';
                echo "<p>\n";
                foreach ( $the_likes as $the_like ) {
                    $i++;
                    $like_list .= "<a href=\"" . esc_url( get_permalink( $the_like ) ) . "\" title=\"" . esc_attr( get_the_title( $the_like ) ) . "\">" . get_the_title( $the_like ) . "</a>\n";
                    if ($count != $i) $like_list .= " &middot; ";
                    else $like_list .= "</p>\n";
                }
                echo $like_list;
            } else {
                echo "<p>" . _e( 'لم تعجب باي مقالة بعد!.' ) . "</p>\n";
            } ?>
            </td>
        </tr>
    </table>
<?php }

/**
 * (6) Add a shortcode to your posts instead
 * type [jmliker] in your post to output the button
 */
function jm_like_shortcode() {
    return getPostLikeLink( get_the_ID() );
}
add_shortcode('jmliker', 'jm_like_shortcode');

/**
 * (7) If the user is logged in, output a list of posts that the user likes
 * Markup assumes sidebar/widget usage
 */
function frontEndUserLikes() {
    if ( is_user_logged_in() ) { // user is logged in
        $like_list = '';
        $user_id = get_current_user_id(); // current user
        $user_likes = get_user_option( "_liked_posts", $user_id );
        if ( !empty( $user_likes ) && count( $user_likes ) > 0 ) {
            $the_likes = $user_likes;
        } else {
            $the_likes = '';
        }
        if ( !is_array( $the_likes ) )
            $the_likes = array();
        $count = count( $the_likes );
        if ( $count > 0 ) {
            $limited_likes = array_slice( $the_likes, 0, 5 ); // this will limit the number of posts returned to 5
            $like_list .= "<aside>\n";
            $like_list .= "<h3>" . __( 'You Like:' ) . "</h3>\n";
            $like_list .= "<ul>\n";
            foreach ( $limited_likes as $the_like ) {
                $like_list .= "<li><a href='" . esc_url( get_permalink( $the_like ) ) . "' title='" . esc_attr( get_the_title( $the_like ) ) . "'>" . get_the_title( $the_like ) . "</a></li>\n";
            }
            $like_list .= "</ul>\n";
            $like_list .= "</aside>\n";
        }
        echo $like_list;
    }
}

/**
 * (8) Outputs a list of the 5 posts with the most user likes TODAY
 * Markup assumes sidebar/widget usage
 */
function jm_most_popular_today() {
    global $post;
    $today = date('j');
    $year = date('Y');
    $args = array(
        'year' => $year,
        'day' => $today,
        'post_type' => array( 'post', 'enter-your-comma-separated-post-types-here' ),
        'meta_query' => array(
              array(
                  'key' => '_post_like_count',
                  'value' => '0',
                  'compare' => '>'
              )
          ),
        'meta_key' => '_post_like_count',
        'orderby' => 'meta_value_num',
        'order' => 'DESC',
        'posts_per_page' => 5
        );
    $pop_posts = new WP_Query( $args );
    if ( $pop_posts->have_posts() ) {
        echo "<aside>\n";
        echo "<h3>" . _e( 'Today\'s Most Popular Posts' ) . "</h3>\n";
        echo "<ul>\n";
        while ( $pop_posts->have_posts() ) {
            $pop_posts->the_post();
            echo "<li><a href='" . get_permalink($post->ID) . "'>" . get_the_title() . "</a></li>\n";
        }
        echo "</ul>\n";
        echo "</aside>\n";
    }
    wp_reset_postdata();
}

/**
 * (9) Outputs a list of the 5 posts with the most user likes for THIS MONTH
 * Markup assumes sidebar/widget usage
 */
function jm_most_popular_month() {
    global $post;
    $month = date('m');
    $year = date('Y');
    $args = array(
        'year' => $year,
        'monthnum' => $month,
        'post_type' => array( 'post', 'enter-your-comma-separated-post-types-here' ),
        'meta_query' => array(
              array(
                  'key' => '_post_like_count',
                  'value' => '0',
                  'compare' => '>'
              )
          ),
        'meta_key' => '_post_like_count',
        'orderby' => 'meta_value_num',
        'order' => 'DESC',
        'posts_per_page' => 5
        );
    $pop_posts = new WP_Query( $args );
    if ( $pop_posts->have_posts() ) {
        echo "<aside>\n";
        echo "<h3>" . _e( 'This Month\'s Most Popular Posts' ) . "</h3>\n";
        echo "<ul>\n";
        while ( $pop_posts->have_posts() ) {
            $pop_posts->the_post();
            echo "<li><a href='" . get_permalink($post->ID) . "'>" . get_the_title() . "</a></li>\n";
        }
        echo "</ul>\n";
        echo "</aside>\n";
    }
    wp_reset_postdata();
}

/**
 * (10) Outputs a list of the 5 posts with the most user likes for THIS WEEK
 * Markup assumes sidebar/widget usage
 */
function jm_most_popular_week() {
    global $post;
    $week = date('W');
    $year = date('Y');
    $args = array(
        'year' => $year,
        'w' => $week,
        'post_type' => array( 'post', 'enter-your-comma-separated-post-types-here' ),
        'meta_query' => array(
              array(
                  'key' => '_post_like_count',
                  'value' => '0',
                  'compare' => '>'
              )
          ),
        'meta_key' => '_post_like_count',
        'orderby' => 'meta_value_num',
        'order' => 'DESC',
        'posts_per_page' => 5
        );
    $pop_posts = new WP_Query( $args );
    if ( $pop_posts->have_posts() ) {
        echo "<aside>\n";
        echo "<h3>" . _e( 'This Week\'s Most Popular Posts' ) . "</h3>\n";
        echo "<ul>\n";
        while ( $pop_posts->have_posts() ) {
            $pop_posts->the_post();
            echo "<li><a href='" . get_permalink($post->ID) . "'>" . get_the_title() . "</a></li>\n";
        }
        echo "</ul>\n";
        echo "</aside>\n";
    }
    wp_reset_postdata();
}

/**
 * (11) Outputs a list of the 5 posts with the most user likes for ALL TIME
 * Markup assumes sidebar/widget usage
 */
function jm_most_popular() {
    global $post;
    echo "<aside>\n";
    echo "<h3>" . _e( 'Most Popular Posts' ) . "</h3>\n";
    echo "<ul>\n";
    $args = array(
         'post_type' => array( 'post', 'enter-your-comma-separated-post-types-here' ),
         'meta_query' => array(
              array(
                  'key' => '_post_like_count',
                  'value' => '0',
                  'compare' => '>'
              )
          ),
         'meta_key' => '_post_like_count',
         'orderby' => 'meta_value_num',
         'order' => 'DESC',
         'posts_per_page' => 5 
         );
    $pop_posts = new WP_Query( $args );
    while ( $pop_posts->have_posts() ) {
        $pop_posts->the_post();
        echo "<li><a href='" . get_permalink($post->ID) . "'>" . get_the_title() . "</a></li>\n";
    }
    wp_reset_postdata();
    echo "</ul>\n";
    echo "</aside>\n";
}

/*****/
add_action( 'admin_menu', 'classic_options_menu_page' );

function classic_options_menu_page() {
    add_menu_page('اعدادات القالب','كلاسيكي','manage_options','classical_options','classic_options', get_template_directory_uri().'/img/options_bar_icon.png');
}

function classic_options() {
    echo '
        <div style="width: 100%;">
            <img style="width: 98%;" src="'.get_template_directory_uri().'/img/adminpic.jpg" alt="">
            <div style="position: absolute;top: 30%;right: 35%;text-align: center;">
                <h2>لوحة التحكم متوفرة فقط في النسخة المدفوعة</h2>
                <h1><a href="http://www.picalica.com/item/classical-arabic-blogging-wordpress-template/707" target="_blank">اشتري الان!</a></h1>
            </div>
        </div>
    ';
}