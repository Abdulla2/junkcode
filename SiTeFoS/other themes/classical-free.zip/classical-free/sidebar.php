    <div id="sidr" class="sidebar">
      <div class="widget widget-about">
          <div class="author mb">
              <?php echo get_avatar(get_option('admin_email'), 128); ?>
              <div class="about-data">
                  <span>محدثكم</span>
                  <a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a>
              </div>
          </div>
          <p>
              <?php the_author_meta('description', 1); ?>
          </p>
      </div><!-- End widget-about -->
      <nav class="site-nav mb">
        <?php 
          wp_nav_menu(array(
              'theme_location' => 'sidebar-menu',
              'container'      => FALSE,
              'menu_class'     => ''
          ));
        ?>
      </nav>
      <?php 
        if ( is_active_sidebar( 'sidebar_menu' ) ) :
            dynamic_sidebar( 'sidebar_menu' );
        endif; 
      ?>
    </div><!-- End sidebar -->