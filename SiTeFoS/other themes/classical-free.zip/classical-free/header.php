<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php bloginfo('name'); ?><?php wp_title('|', TRUE, 'left'); ?></title>
    <link rel="icon" href="">
    <meta name="description" content="<?php bloginfo('description') ?>">
    <!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="<?php echo THEMROOT ?>/css/fonts/amiri.css">
    <link rel="stylesheet" href="<?php echo THEMROOT ?>/style.css">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

    <?php get_sidebar(); ?>
    
<div class="content-all">

    <?php get_search_form(); ?>
    
    <header class="top-bar navbar-fixed-top">
        <div class="container">
            <div class="row">
                <span class="simple-menu fa fa-bars pull-right"></span>
                <a href="<?php echo home_url(); ?>" class="title"><?php bloginfo('name'); ?></a>
                <a class="fa fa-search pull-left search-icon"></a>
            </div><!-- End row -->
        </div><!-- End container -->
    </header><!-- End top-bar -->


    <header class="header"> 
        <div class="container">
           <div class="row">
               <span class="simple-menu fa fa-bars pull-right"></span>
               <label class="fa fa-search pull-left search-icon" for="search"></label>
               <div>
                    <a href="<?php echo home_url(); ?>" class="logo">
                        <?php echo get_avatar(get_option('admin_email'), 128); ?>
                    </a>
                    <div>
                        <a href="<?php echo home_url(); ?>" class="title"><?php bloginfo('name'); ?></a>
                    </div>
                    <p><?php echo get_option('blogdescription'); ?></p>
                </div>
           </div><!-- End row -->
        </div><!-- End container -->
    </header><!-- End header -->