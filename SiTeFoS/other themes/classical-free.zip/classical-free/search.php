<?php get_header(); ?>

<div class="content-wrap">
    <section class="posts">
        <div class="container">
           <div class="row">

            <?php if (have_posts()) :
            
                $read_more_text = 'اقرأ المزيد';
                    while(have_posts()) :
                        the_post();

$btn_like = '<li class="post-like">'.getPostLikeLink(get_the_ID()).'</li>';
$btn_share = '
<li class="dropup">
  <span class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
       <i class="fa fa-share-alt"></i>
   </span>
  <ul class="dropdown-menu" role="menu">
      <li>
        <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u='.wp_get_shortlink().'">
          <i class="fa fa-facebook"></i>
        </a>
      </li>
      <li class="divider"></li>
      <li>
        <a target="_blank" href="https://twitter.com/intent/tweet?text='.get_the_title().'&url='.wp_get_shortlink().'">
          <i class="fa fa-twitter"></i>
        </a>
      </li>
      <li class="divider"></li>
      <li>
        <a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url='.wp_get_shortlink().'">
          <i class="fa fa-linkedin"></i>
        </a>
      </li>
  </ul>
</li>';

$post_date_option = '<span class="post-date">'.get_the_date().'</span>';

    if (has_post_thumbnail(get_the_ID())) {
    ?>
               <!-- Start post/text-img-post -->
               <article class="post text-img-post">
                   <header class="post-header">
                        <?php the_post_thumbnail( array(760, 355) ); ?>
                   </header><!-- End post-header -->
                   <div class="post-content">
                        <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                        <?php 
                          if (get_the_content()) :
                            echo wp_trim_words(get_the_content(), 85); ?>
                            <p class="read-more"><a href="<?php the_permalink(); ?>"><?php echo $read_more_text; ?></a></p>
                          <?php endif; ?>
                   </div><!-- End post-content -->
                   <footer class="post-footer">
                       <?php echo $post_date_option; ?>
                       <ul class="post-share">
                            <?php echo $btn_like; ?>
                           <?php echo $btn_share; ?>
                       </ul><!-- End post-share -->
                   </footer><!-- End post-footer -->
               </article><!-- End post/text-img-post -->
    <?php
    } else {
    ?>
               <!-- Start post/text-post -->
               <article class="post text-post">
                   <header class="post-header">
                        <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                   </header><!-- End post-header -->
                   <div class="post-content">
                   <?php 
                      if (get_the_content()) :
                        echo wp_trim_words(get_the_content(), 85); ?>
                        <p class="read-more"><a href="<?php the_permalink(); ?>"><?php echo $read_more_text; ?></a></p>
                        <?php endif; ?>
                   </div><!-- End post-content -->
                   <footer class="post-footer">
                       <?php echo $post_date_option; ?>
                       <ul class="post-share">
                            <?php echo $btn_like; ?>
                           <?php echo $btn_share; ?>
                       </ul><!-- End post-share -->
                   </footer><!-- End post-footer -->
               </article><!-- End post/text-post -->
        <?php
            }
        ?>
                <?php 
                    endwhile; 
                  else :
                    echo "
                    <div class='align-center'>
                        <h3>لم يتم العثور على نتائج</h3>
                        <p>عزرا, لم يتم العثور على نتائج تطابق كلمة البحث التي ادخلتها, حاول البحث بإستخدام كلمات اخرى.</p>
                    </div>";
                  endif;
                ?>
           </div><!-- End row -->
        </div><!-- End container -->
    </section><!-- End posts -->
    
    <?php 
        global $wp_query;
        if ($wp_query->max_num_pages > 1) :
    ?>

    <!-- Start pagination-page -->
    <div class="pagination-page align-center">
       <div class="container">
           <div class="row">
                <?php 
                    if (get_query_var('paged')) :
                        $num_page = (int)get_query_var('paged');
                    else :
                        $num_page = 1;
                    endif;
                ?>
                <span>الصفحة <?php echo $num_page; ?> من <?php echo $wp_query->max_num_pages; ?></span>
                <span rel="next">
                <?php 
                    next_posts_link('<span>الصفحة التالية</span><i class="fa fa-long-arrow-left"></i>',$wp_query->max_num_pages);
                ?>
                </span>
                <span rel="prev">
                <?php
                    previous_posts_link('<i class="fa fa-long-arrow-right"></i><span>الصفحة السابقة</span>',$wp_query->max_num_pages); 
                ?>
                </span>
           </div><!-- End row -->
       </div><!-- End container -->
    </div><!-- End pagination-page -->
    
    <?php endif; ?>


<?php get_footer(); ?>