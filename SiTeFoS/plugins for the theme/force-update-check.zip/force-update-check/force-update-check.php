<?php
/*
Plugin Name: Force Update Check
Plugin URI: http://w-shadow.com/blog/2009/10/01/force-update-check-plugin/
Description: Gives you the ability to make WordPress check for new plugin, theme and core updates immediately, instead of waiting for up to 12 hours until they show up.
Version: 1.0
Author: Janis Elsts
Author URI: http://w-shadow.com/blog/
*/

if ( is_admin() ){
	
class ForceUpdateCheck{
	
	function ForceUpdateCheck() {
		add_action('admin_menu', array( &$this, 'add_menu' ) );
	}
	
	function add_menu(){
		add_submenu_page(
			'plugins.php',
			'Check For Updates Now', 
			'Check Updates Now', 
			'update_plugins', 
			'check-updates-now', 
			array( &$this, 'page_check_updates')
		);	
		
		add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), array( &$this, 'action_links' ), 10, 2 ); 
	}
	
	function page_check_updates(){
		echo '<div class="wrap">';
		screen_icon( 'tools' );
		echo '<h2>Checking For Updates...</h2>';
		
		echo "<h3>";
		$current = get_transient( 'update_plugins' );	//Get the current update info
		$current->last_checked = 0;						//wp_update_plugins() checks this value when determining  
		set_transient( 'update_plugins', $current );	//whether to actually check for updates, so we reset it to zero.
		wp_update_plugins();							//Run the internal plugin update check
		
		$current = get_transient( 'update_plugins' );
		$plugin_update_cnt = ( isset( $current->response ) && is_array( $current->response ) ) ? count($current->response) : 0;
		
		if ( $plugin_update_cnt > 0 ) {
			$url = admin_url('plugins.php?plugin_status=upgrade');
			echo sprintf( '<a href="%s" title="View available plugin upgrades">Found %d plugin updates!</a>', $url, $plugin_update_cnt );
		} else {
			echo "No plugin updates found.";
		}
		echo "</h3>";
		
		//---------------------------------------
		echo "<h3>";
		
		$current = get_transient( 'update_themes' );
		$current->last_checked = 0;
		set_transient( 'update_themes', $current );
		wp_update_themes();
		
		$current = get_transient( 'update_themes' );
		$theme_update_cnt = ( isset( $current->response ) && is_array( $current->response ) ) ? count($current->response) : 0;
		
		if ( $theme_update_cnt > 0 ) {
			$url = admin_url('themes.php');
			echo sprintf( '<a href="%s" title="View available theme upgrades">Found %d theme updates!</a>', $url, $theme_update_cnt );
		} else {
			echo "No theme updates found.";
		}
		echo "</h3>";
		
				
		//---------------------------------------
		echo "<h3>";
		
		$current = get_transient( 'update_core' );
		$current->last_checked = 0;
		set_transient( 'update_core', $current );
		wp_version_check();
		
		$latest_core_update = get_preferred_from_update_core();
		if ( isset( $latest_core_update->response ) && ( $latest_core_update->response == 'upgrade' ) ){
			$url = admin_url('update-core.php');
			echo sprintf( '<a href="%s" title="Upgrade WordPress now">Found a new WordPres version. Install it now.</a>', $url );
		} else {
			echo "No core updates found.";
		}
		echo '</h3>';
		
		  
		echo '</div>';
	}
	
	function action_links( $actions, $plugin_file ){
		if ( current_user_can('update_plugins') ){
			//Add the "Run" link to the plugin's action links
			$actions[] = sprintf( '<a href="%s" title="Check for updates now">Run</a>', admin_url('plugins.php?page=check-updates-now') );
		}
		return $actions;
	}
	
}	
	
$force_update_check = new ForceUpdateCheck;

}







































?>