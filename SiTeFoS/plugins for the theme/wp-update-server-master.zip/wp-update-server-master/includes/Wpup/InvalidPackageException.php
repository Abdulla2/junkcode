<?php
/**
 * Exception thrown when the server fails to parse a plugin/theme.
 */
class Wpup_InvalidPackageException extends RuntimeException { }
