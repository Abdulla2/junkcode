# WP Test Changelog

## 1.5.0

* Gives the README a serious makeover.
* #9: Moves "Menu Description" custom menu item under "Advanced" menu
* #12: Removes inline styles being added to the data
* #23: Fixes "Captain America" typo in tiled gallery post
* #24: Fixes incorrect alt text on vertical featured image post
* #27: Fixes "E = MC2" quote typo
* #36: Adds `CONTRIBUTING.md` file

## 1.4.2

* #34: Adds `-L` to curl request so that redirects are followed in the WP-CLI script

## 1.4.1

* #31: Fix path to raw XML file for WP-CLI script

## 1.4.0

* #18: Adds WP-CLI quick install script

## 1.3.0

* #20: Adds composer file.

## 1.2.0

* Adds uploads for people having issues with WordPress Importer not pulling in the files

## 1.1.1

* #4: Fixes "developer" typo on Steve Ballmer quote

## 1.1.0

* #2: Adds sticky post test

## 1.0.0

* Initial release